import { MastraBase } from '@mastra/core/base';
import type { RuntimeContext } from '@mastra/core/di';
import type { SSEClientTransportOptions } from '@modelcontextprotocol/sdk/client/sse.js';
import type { StreamableHTTPClientTransportOptions } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import type { ClientCapabilities, GetPromptResult, ListPromptsResult, LoggingLevel } from '@modelcontextprotocol/sdk/types.js';
import { ResourceUpdatedNotificationSchema } from '@modelcontextprotocol/sdk/types.js';
import { z } from 'zod';
import { PromptClientActions } from './promptActions';
import { ResourceClientActions } from './resourceActions';
export type { LoggingLevel } from '@modelcontextprotocol/sdk/types.js';
export interface LogMessage {
    level: LoggingLevel;
    message: string;
    timestamp: Date;
    serverName: string;
    details?: Record<string, any>;
    runtimeContext?: RuntimeContext | null;
}
export type LogHandler = (logMessage: LogMessage) => void;
type BaseServerOptions = {
    logger?: LogHandler;
    timeout?: number;
    capabilities?: ClientCapabilities;
    enableServerLogs?: boolean;
};
type StdioServerDefinition = BaseServerOptions & {
    command: string;
    args?: string[];
    env?: Record<string, string>;
    url?: never;
    requestInit?: never;
    eventSourceInit?: never;
    reconnectionOptions?: never;
    sessionId?: never;
};
type HttpServerDefinition = BaseServerOptions & {
    url: URL;
    command?: never;
    args?: never;
    env?: never;
    requestInit?: StreamableHTTPClientTransportOptions['requestInit'];
    eventSourceInit?: SSEClientTransportOptions['eventSourceInit'];
    reconnectionOptions?: StreamableHTTPClientTransportOptions['reconnectionOptions'];
    sessionId?: StreamableHTTPClientTransportOptions['sessionId'];
};
export type MastraMCPServerDefinition = StdioServerDefinition | HttpServerDefinition;
export type InternalMastraMCPClientOptions = {
    name: string;
    server: MastraMCPServerDefinition;
    capabilities?: ClientCapabilities;
    version?: string;
    timeout?: number;
};
export declare class InternalMastraMCPClient extends MastraBase {
    name: string;
    private client;
    private readonly timeout;
    private logHandler?;
    private enableServerLogs?;
    private serverConfig;
    private transport?;
    private currentOperationContext;
    readonly resources: ResourceClientActions;
    readonly prompts: PromptClientActions;
    constructor({ name, version, server, capabilities, timeout, }: InternalMastraMCPClientOptions);
    /**
     * Log a message at the specified level
     * @param level Log level
     * @param message Log message
     * @param details Optional additional details
     */
    private log;
    private setupLogging;
    private connectStdio;
    private connectHttp;
    private isConnected;
    connect(): Promise<boolean>;
    /**
     * Get the current session ID if using the Streamable HTTP transport.
     * Returns undefined if not connected or not using Streamable HTTP.
     */
    get sessionId(): string | undefined;
    disconnect(): Promise<void>;
    listResources(): Promise<z.objectOutputType<{
        _meta: z.ZodOptional<z.ZodObject<{}, "passthrough", z.ZodTypeAny, z.objectOutputType<{}, z.ZodTypeAny, "passthrough">, z.objectInputType<{}, z.ZodTypeAny, "passthrough">>>;
    } & {
        nextCursor: z.ZodOptional<z.ZodString>;
    } & {
        resources: z.ZodArray<z.ZodObject<{
            uri: z.ZodString;
            name: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
            mimeType: z.ZodOptional<z.ZodString>;
        }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
            uri: z.ZodString;
            name: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
            mimeType: z.ZodOptional<z.ZodString>;
        }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
            uri: z.ZodString;
            name: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
            mimeType: z.ZodOptional<z.ZodString>;
        }, z.ZodTypeAny, "passthrough">>, "many">;
    }, z.ZodTypeAny, "passthrough">>;
    readResource(uri: string): Promise<z.objectOutputType<{
        _meta: z.ZodOptional<z.ZodObject<{}, "passthrough", z.ZodTypeAny, z.objectOutputType<{}, z.ZodTypeAny, "passthrough">, z.objectInputType<{}, z.ZodTypeAny, "passthrough">>>;
    } & {
        contents: z.ZodArray<z.ZodUnion<[z.ZodObject<z.objectUtil.extendShape<{
            uri: z.ZodString;
            mimeType: z.ZodOptional<z.ZodString>;
        }, {
            text: z.ZodString;
        }>, "passthrough", z.ZodTypeAny, z.objectOutputType<z.objectUtil.extendShape<{
            uri: z.ZodString;
            mimeType: z.ZodOptional<z.ZodString>;
        }, {
            text: z.ZodString;
        }>, z.ZodTypeAny, "passthrough">, z.objectInputType<z.objectUtil.extendShape<{
            uri: z.ZodString;
            mimeType: z.ZodOptional<z.ZodString>;
        }, {
            text: z.ZodString;
        }>, z.ZodTypeAny, "passthrough">>, z.ZodObject<z.objectUtil.extendShape<{
            uri: z.ZodString;
            mimeType: z.ZodOptional<z.ZodString>;
        }, {
            blob: z.ZodString;
        }>, "passthrough", z.ZodTypeAny, z.objectOutputType<z.objectUtil.extendShape<{
            uri: z.ZodString;
            mimeType: z.ZodOptional<z.ZodString>;
        }, {
            blob: z.ZodString;
        }>, z.ZodTypeAny, "passthrough">, z.objectInputType<z.objectUtil.extendShape<{
            uri: z.ZodString;
            mimeType: z.ZodOptional<z.ZodString>;
        }, {
            blob: z.ZodString;
        }>, z.ZodTypeAny, "passthrough">>]>, "many">;
    }, z.ZodTypeAny, "passthrough">>;
    subscribeResource(uri: string): Promise<{}>;
    unsubscribeResource(uri: string): Promise<{}>;
    listResourceTemplates(): Promise<z.objectOutputType<{
        _meta: z.ZodOptional<z.ZodObject<{}, "passthrough", z.ZodTypeAny, z.objectOutputType<{}, z.ZodTypeAny, "passthrough">, z.objectInputType<{}, z.ZodTypeAny, "passthrough">>>;
    } & {
        nextCursor: z.ZodOptional<z.ZodString>;
    } & {
        resourceTemplates: z.ZodArray<z.ZodObject<{
            uriTemplate: z.ZodString;
            name: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
            mimeType: z.ZodOptional<z.ZodString>;
        }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
            uriTemplate: z.ZodString;
            name: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
            mimeType: z.ZodOptional<z.ZodString>;
        }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
            uriTemplate: z.ZodString;
            name: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
            mimeType: z.ZodOptional<z.ZodString>;
        }, z.ZodTypeAny, "passthrough">>, "many">;
    }, z.ZodTypeAny, "passthrough">>;
    /**
     * Fetch the list of available prompts from the MCP server.
     */
    listPrompts(): Promise<ListPromptsResult>;
    /**
     * Get a prompt and its dynamic messages from the server.
     * @param name The prompt name
     * @param args Arguments for the prompt
     * @param version (optional) The prompt version to retrieve
     */
    getPrompt({ name, args, version, }: {
        name: string;
        args?: Record<string, any>;
        version?: string;
    }): Promise<GetPromptResult>;
    /**
     * Register a handler to be called when the prompt list changes on the server.
     * Use this to refresh cached prompt lists in the client/UI if needed.
     */
    setPromptListChangedNotificationHandler(handler: () => void): void;
    setResourceUpdatedNotificationHandler(handler: (params: z.infer<typeof ResourceUpdatedNotificationSchema>['params']) => void): void;
    setResourceListChangedNotificationHandler(handler: () => void): void;
    private convertInputSchema;
    tools(): Promise<Record<string, any>>;
}
/**
 * @deprecated MastraMCPClient is deprecated and will be removed in a future release. Please use MCPClient instead.
 */
export declare class MastraMCPClient extends InternalMastraMCPClient {
    constructor(args: InternalMastraMCPClientOptions);
}
//# sourceMappingURL=client.d.ts.map