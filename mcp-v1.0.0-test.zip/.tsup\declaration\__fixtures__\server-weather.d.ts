export {};
//# sourceMappingURL=server-weather.d.ts.map