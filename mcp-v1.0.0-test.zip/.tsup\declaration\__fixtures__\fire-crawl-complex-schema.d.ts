#!/usr/bin/env node
import type { ToolsInput } from '@mastra/core/agent';
export declare const allTools: ToolsInput;
export declare const mcpServerName = "firecrawl-mcp-fixture";
//# sourceMappingURL=fire-crawl-complex-schema.d.ts.map