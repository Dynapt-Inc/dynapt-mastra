import type { IMastraLogger } from "@mastra/core/logger";
import type { GetPromptResult, Prompt } from "@modelcontextprotocol/sdk/types.js";
import type { InternalMastraMCPClient } from "./client";
interface PromptClientActionsConfig {
    client: InternalMastraMCPClient;
    logger: IMastraLogger;
}
/**
 * Client-side prompt actions for listing, getting, and subscribing to prompt changes.
 */
export declare class PromptClientActions {
    private readonly client;
    private readonly logger;
    constructor({ client, logger }: PromptClientActionsConfig);
    /**
     * Get all prompts from the connected MCP server.
     * @returns A list of prompts with their versions.
     */
    list(): Promise<Prompt[]>;
    /**
     * Get a specific prompt.
     * @param name The name of the prompt to get.
     * @param args Optional arguments for the prompt.
     * @param version Optional version of the prompt to get.
     * @returns The prompt content.
     */
    get({ name, args, version }: {
        name: string;
        args?: Record<string, any>;
        version?: string;
    }): Promise<GetPromptResult>;
    /**
     * Set a notification handler for when the list of available prompts changes.
     * @param handler The callback function to handle the notification.
     */
    onListChanged(handler: () => void): Promise<void>;
}
export {};
//# sourceMappingURL=promptActions.d.ts.map