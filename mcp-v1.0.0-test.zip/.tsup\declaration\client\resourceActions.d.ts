import type { IMastraLogger } from "@mastra/core/logger";
import type { Resource, ResourceTemplate } from "@modelcontextprotocol/sdk/types.js";
import type { InternalMastraMCPClient } from "./client";
interface ResourceClientActionsConfig {
    client: InternalMastraMCPClient;
    logger: IMastraLogger;
}
export declare class ResourceClientActions {
    private readonly client;
    private readonly logger;
    constructor({ client, logger }: ResourceClientActionsConfig);
    /**
     * Get all resources from the connected MCP server.
     * @returns A list of resources.
     */
    list(): Promise<Resource[]>;
    /**
     * Get all resource templates from the connected MCP server.
     * @returns A list of resource templates.
     */
    templates(): Promise<ResourceTemplate[]>;
    /**
     * Read a specific resource.
     * @param uri The URI of the resource to read.
     * @returns The resource content.
     */
    read(uri: string): Promise<import("zod").objectOutputType<{
        _meta: import("zod").ZodOptional<import("zod").ZodObject<{}, "passthrough", import("zod").ZodTypeAny, import("zod").objectOutputType<{}, import("zod").ZodTypeAny, "passthrough">, import("zod").objectInputType<{}, import("zod").ZodTypeAny, "passthrough">>>;
    } & {
        contents: import("zod").ZodArray<import("zod").ZodUnion<[import("zod").ZodObject<import("zod").objectUtil.extendShape<{
            uri: import("zod").ZodString;
            mimeType: import("zod").ZodOptional<import("zod").ZodString>;
        }, {
            text: import("zod").ZodString;
        }>, "passthrough", import("zod").ZodTypeAny, import("zod").objectOutputType<import("zod").objectUtil.extendShape<{
            uri: import("zod").ZodString;
            mimeType: import("zod").ZodOptional<import("zod").ZodString>;
        }, {
            text: import("zod").ZodString;
        }>, import("zod").ZodTypeAny, "passthrough">, import("zod").objectInputType<import("zod").objectUtil.extendShape<{
            uri: import("zod").ZodString;
            mimeType: import("zod").ZodOptional<import("zod").ZodString>;
        }, {
            text: import("zod").ZodString;
        }>, import("zod").ZodTypeAny, "passthrough">>, import("zod").ZodObject<import("zod").objectUtil.extendShape<{
            uri: import("zod").ZodString;
            mimeType: import("zod").ZodOptional<import("zod").ZodString>;
        }, {
            blob: import("zod").ZodString;
        }>, "passthrough", import("zod").ZodTypeAny, import("zod").objectOutputType<import("zod").objectUtil.extendShape<{
            uri: import("zod").ZodString;
            mimeType: import("zod").ZodOptional<import("zod").ZodString>;
        }, {
            blob: import("zod").ZodString;
        }>, import("zod").ZodTypeAny, "passthrough">, import("zod").objectInputType<import("zod").objectUtil.extendShape<{
            uri: import("zod").ZodString;
            mimeType: import("zod").ZodOptional<import("zod").ZodString>;
        }, {
            blob: import("zod").ZodString;
        }>, import("zod").ZodTypeAny, "passthrough">>]>, "many">;
    }, import("zod").ZodTypeAny, "passthrough">>;
    /**
     * Subscribe to a specific resource.
     * @param uri The URI of the resource to subscribe to.
     */
    subscribe(uri: string): Promise<{}>;
    /**
     * Unsubscribe from a specific resource.
     * @param uri The URI of the resource to unsubscribe from.
     */
    unsubscribe(uri: string): Promise<{}>;
    /**
     * Set a notification handler for when a specific resource is updated.
     * @param handler The callback function to handle the notification.
     */
    onUpdated(handler: (params: {
        uri: string;
    }) => void): Promise<void>;
    /**
     * Set a notification handler for when the list of available resources changes.
     * @param handler The callback function to handle the notification.
     */
    onListChanged(handler: () => void): Promise<void>;
}
export {};
//# sourceMappingURL=resourceActions.d.ts.map