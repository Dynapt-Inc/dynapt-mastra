import { MastraBase } from '@mastra/core/base';
import type { Prompt, Resource, ResourceTemplate } from '@modelcontextprotocol/sdk/types.js';
import type { MastraMCPServerDefinition } from './client';
export interface MCPClientOptions {
    id?: string;
    servers: Record<string, MastraMCPServerDefinition>;
    timeout?: number;
}
export declare class MCPClient extends MastraBase {
    private serverConfigs;
    private id;
    private defaultTimeout;
    private mcpClientsById;
    private disconnectPromise;
    constructor(args: MCPClientOptions);
    get resources(): {
        list: () => Promise<Record<string, Resource[]>>;
        templates: () => Promise<Record<string, ResourceTemplate[]>>;
        read: (serverName: string, uri: string) => Promise<import("zod").objectOutputType<{
            _meta: import("zod").ZodOptional<import("zod").ZodObject<{}, "passthrough", import("zod").ZodTypeAny, import("zod").objectOutputType<{}, import("zod").ZodTypeAny, "passthrough">, import("zod").objectInputType<{}, import("zod").ZodTypeAny, "passthrough">>>;
        } & {
            contents: import("zod").ZodArray<import("zod").ZodUnion<[import("zod").ZodObject<import("zod").objectUtil.extendShape<{
                uri: import("zod").ZodString;
                mimeType: import("zod").ZodOptional<import("zod").ZodString>;
            }, {
                text: import("zod").ZodString;
            }>, "passthrough", import("zod").ZodTypeAny, import("zod").objectOutputType<import("zod").objectUtil.extendShape<{
                uri: import("zod").ZodString;
                mimeType: import("zod").ZodOptional<import("zod").ZodString>;
            }, {
                text: import("zod").ZodString;
            }>, import("zod").ZodTypeAny, "passthrough">, import("zod").objectInputType<import("zod").objectUtil.extendShape<{
                uri: import("zod").ZodString;
                mimeType: import("zod").ZodOptional<import("zod").ZodString>;
            }, {
                text: import("zod").ZodString;
            }>, import("zod").ZodTypeAny, "passthrough">>, import("zod").ZodObject<import("zod").objectUtil.extendShape<{
                uri: import("zod").ZodString;
                mimeType: import("zod").ZodOptional<import("zod").ZodString>;
            }, {
                blob: import("zod").ZodString;
            }>, "passthrough", import("zod").ZodTypeAny, import("zod").objectOutputType<import("zod").objectUtil.extendShape<{
                uri: import("zod").ZodString;
                mimeType: import("zod").ZodOptional<import("zod").ZodString>;
            }, {
                blob: import("zod").ZodString;
            }>, import("zod").ZodTypeAny, "passthrough">, import("zod").objectInputType<import("zod").objectUtil.extendShape<{
                uri: import("zod").ZodString;
                mimeType: import("zod").ZodOptional<import("zod").ZodString>;
            }, {
                blob: import("zod").ZodString;
            }>, import("zod").ZodTypeAny, "passthrough">>]>, "many">;
        }, import("zod").ZodTypeAny, "passthrough">>;
        subscribe: (serverName: string, uri: string) => Promise<{}>;
        unsubscribe: (serverName: string, uri: string) => Promise<{}>;
        onUpdated: (serverName: string, handler: (params: {
            uri: string;
        }) => void) => Promise<void>;
        onListChanged: (serverName: string, handler: () => void) => Promise<void>;
    };
    get prompts(): {
        list: () => Promise<Record<string, Prompt[]>>;
        get: ({ serverName, name, args, version }: {
            serverName: string;
            name: string;
            args?: Record<string, any>;
            version?: string;
        }) => Promise<{
            [x: string]: unknown;
            messages: {
                [x: string]: unknown;
                role: "user" | "assistant";
                content: {
                    [x: string]: unknown;
                    type: "text";
                    text: string;
                } | {
                    [x: string]: unknown;
                    type: "image";
                    data: string;
                    mimeType: string;
                } | {
                    [x: string]: unknown;
                    type: "audio";
                    data: string;
                    mimeType: string;
                } | {
                    [x: string]: unknown;
                    type: "resource";
                    resource: {
                        [x: string]: unknown;
                        text: string;
                        uri: string;
                        mimeType?: string | undefined;
                    } | {
                        [x: string]: unknown;
                        uri: string;
                        blob: string;
                        mimeType?: string | undefined;
                    };
                };
            }[];
            description?: string | undefined;
            _meta?: {
                [x: string]: unknown;
            } | undefined;
        }>;
        onListChanged: (serverName: string, handler: () => void) => Promise<void>;
    };
    private addToInstanceCache;
    private makeId;
    disconnect(): Promise<void>;
    getTools(): Promise<Record<string, any>>;
    getToolsets(): Promise<Record<string, Record<string, any>>>;
    /**
     * @deprecated all resource actions have been moved to the this.resources object. Use this.resources.list() instead.
     */
    getResources(): Promise<Record<string, {
        [x: string]: unknown;
        name: string;
        uri: string;
        description?: string | undefined;
        mimeType?: string | undefined;
    }[]>>;
    /**
     * Get the current session IDs for all connected MCP clients using the Streamable HTTP transport.
     * Returns an object mapping server names to their session IDs.
     */
    get sessionIds(): Record<string, string>;
    private getConnectedClient;
    private getConnectedClientForServer;
    private eachClientTools;
}
/**
 * @deprecated MCPConfigurationOptions is deprecated and will be removed in a future release. Use MCPClientOptions instead.
 */
export interface MCPConfigurationOptions {
    id?: string;
    servers: Record<string, MastraMCPServerDefinition>;
    timeout?: number;
}
/**
 * @deprecated MCPConfiguration is deprecated and will be removed in a future release. Use MCPClient instead.
 */
export declare class MCPConfiguration extends MCPClient {
    constructor(args: MCPClientOptions);
}
//# sourceMappingURL=configuration.d.ts.map