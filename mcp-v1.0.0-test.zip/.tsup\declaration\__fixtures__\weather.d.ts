import { MCPServer } from '../server/server';
declare const mcpServer: MCPServer;
export { mcpServer as server };
//# sourceMappingURL=weather.d.ts.map