import type * as http from 'node:http';
import type { ToolsInput, Agent } from '@mastra/core/agent';
import { MCPServerBase } from '@mastra/core/mcp';
import type { MCPServerConfig, ServerInfo, ServerDetailInfo, ConvertedTool, MCPServerHonoSSEOptions, MCPServerSSEOptions, MCPToolType } from '@mastra/core/mcp';
import type { Workflow } from '@mastra/core/workflows';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import type { StreamableHTTPServerTransportOptions } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import type { SSEStreamingApi } from 'hono/streaming';
import { SSETransport } from 'hono-mcp-server-sse-transport';
import { ServerPromptActions } from './promptActions';
import { ServerResourceActions } from './resourceActions';
import type { MCPServerPrompts, MCPServerResources } from './types';
export declare class MCPServer extends MCPServerBase {
    private server;
    private stdioTransport?;
    private sseTransport?;
    private sseHonoTransports;
    private streamableHTTPTransports;
    private listToolsHandlerIsRegistered;
    private callToolHandlerIsRegistered;
    private listResourcesHandlerIsRegistered;
    private readResourceHandlerIsRegistered;
    private listResourceTemplatesHandlerIsRegistered;
    private subscribeResourceHandlerIsRegistered;
    private unsubscribeResourceHandlerIsRegistered;
    private listPromptsHandlerIsRegistered;
    private getPromptHandlerIsRegistered;
    private definedResources?;
    private definedResourceTemplates?;
    private resourceOptions?;
    private definedPrompts?;
    private promptOptions?;
    private subscriptions;
    readonly resources: ServerResourceActions;
    readonly prompts: ServerPromptActions;
    /**
     * Get the current stdio transport.
     */
    getStdioTransport(): StdioServerTransport | undefined;
    /**
     * Get the current SSE transport.
     */
    getSseTransport(): SSEServerTransport | undefined;
    /**
     * Get the current SSE Hono transport.
     */
    getSseHonoTransport(sessionId: string): SSETransport | undefined;
    /**
     * Get the current server instance.
     */
    getServer(): Server;
    /**
     * Construct a new MCPServer instance.
     * @param opts - Configuration options for the server, including registry metadata.
     */
    constructor(opts: MCPServerConfig & {
        resources?: MCPServerResources;
        prompts?: MCPServerPrompts;
    });
    private convertAgentsToTools;
    private convertWorkflowsToTools;
    /**
     * Convert and validate all provided tools, logging registration status.
     * Also converts agents and workflows into tools.
     * @param tools Tool definitions
     * @param agentsConfig Agent definitions to be converted to tools, expected from MCPServerConfig
     * @param workflowsConfig Workflow definitions to be converted to tools, expected from MCPServerConfig
     * @returns Converted tools registry
     */
    convertTools(tools: ToolsInput, agentsConfig?: Record<string, Agent>, workflowsConfig?: Record<string, Workflow>): Record<string, ConvertedTool>;
    /**
     * Register the ListTools handler for listing all available tools.
     */
    private registerListToolsHandler;
    /**
     * Register the CallTool handler for executing a tool by name.
     */
    private registerCallToolHandler;
    /**
     * Register the ListResources handler for listing all available resources.
     */
    private registerListResourcesHandler;
    /**
     * Register the ReadResource handler for reading a resource by URI.
     */
    private registerReadResourceHandler;
    /**
     * Register the ListResourceTemplates handler.
     */
    private registerListResourceTemplatesHandler;
    /**
     * Register the SubscribeResource handler.
     */
    private registerSubscribeResourceHandler;
    /**
     * Register the UnsubscribeResource handler.
     */
    private registerUnsubscribeResourceHandler;
    /**
     * Register the ListPrompts handler.
     */
    private registerListPromptsHandler;
    /**
     * Register the GetPrompt handler.
     */
    private registerGetPromptHandler;
    /**
     * Start the MCP server using stdio transport (for Windsurf integration).
     */
    startStdio(): Promise<void>;
    /**
     * Handles MCP-over-SSE protocol for user-provided HTTP servers.
     * Call this from your HTTP server for both the SSE and message endpoints.
     *
     * @param url Parsed URL of the incoming request
     * @param ssePath Path for establishing the SSE connection (e.g. '/sse')
     * @param messagePath Path for POSTing client messages (e.g. '/message')
     * @param req Incoming HTTP request
     * @param res HTTP response (must support .write/.end)
     */
    startSSE({ url, ssePath, messagePath, req, res }: MCPServerSSEOptions): Promise<void>;
    /**
     * Handles MCP-over-SSE protocol for user-provided HTTP servers.
     * Call this from your HTTP server for both the SSE and message endpoints.
     *
     * @param url Parsed URL of the incoming request
     * @param ssePath Path for establishing the SSE connection (e.g. '/sse')
     * @param messagePath Path for POSTing client messages (e.g. '/message')
     * @param context Incoming Hono context
     */
    startHonoSSE({ url, ssePath, messagePath, context }: MCPServerHonoSSEOptions): Promise<Response>;
    /**
     * Handles MCP-over-StreamableHTTP protocol for user-provided HTTP servers.
     * Call this from your HTTP server for the streamable HTTP endpoint.
     *
     * @param url Parsed URL of the incoming request
     * @param httpPath Path for establishing the streamable HTTP connection (e.g. '/mcp')
     * @param req Incoming HTTP request
     * @param res HTTP response (must support .write/.end)
     * @param options Optional options to pass to the transport (e.g. sessionIdGenerator)
     */
    startHTTP({ url, httpPath, req, res, options, }: {
        url: URL;
        httpPath: string;
        req: http.IncomingMessage;
        res: http.ServerResponse<http.IncomingMessage>;
        options?: StreamableHTTPServerTransportOptions;
    }): Promise<void>;
    connectSSE({ messagePath, res, }: {
        messagePath: string;
        res: http.ServerResponse<http.IncomingMessage>;
    }): Promise<void>;
    connectHonoSSE({ messagePath, stream }: {
        messagePath: string;
        stream: SSEStreamingApi;
    }): Promise<void>;
    /**
     * Close the MCP server and all its connections
     */
    close(): Promise<void>;
    /**
     * Gets the basic information about the server, conforming to the Server schema.
     * @returns ServerInfo object.
     */
    getServerInfo(): ServerInfo;
    /**
     * Gets detailed information about the server, conforming to the ServerDetail schema.
     * @returns ServerDetailInfo object.
     */
    getServerDetail(): ServerDetailInfo;
    /**
     * Gets a list of tools provided by this MCP server, including their schemas.
     * This leverages the same tool information used by the internal ListTools MCP request.
     * @returns An object containing an array of tool information.
     */
    getToolListInfo(): {
        tools: Array<{
            name: string;
            description?: string;
            inputSchema: any;
            toolType?: MCPToolType;
        }>;
    };
    /**
     * Gets information for a specific tool provided by this MCP server.
     * @param toolId The ID/name of the tool to retrieve.
     * @returns Tool information (name, description, inputSchema) or undefined if not found.
     */
    getToolInfo(toolId: string): {
        name: string;
        description?: string;
        inputSchema: any;
        toolType?: MCPToolType;
    } | undefined;
    /**
     * Executes a specific tool provided by this MCP server.
     * @param toolId The ID/name of the tool to execute.
     * @param args The arguments to pass to the tool's execute function.
     * @param executionContext Optional context for the tool execution.
     * @returns A promise that resolves to the result of the tool execution.
     * @throws Error if the tool is not found, validation fails, or execution fails.
     */
    executeTool(toolId: string, args: any, executionContext?: {
        messages?: any[];
        toolCallId?: string;
    }): Promise<any>;
}
//# sourceMappingURL=server.d.ts.map