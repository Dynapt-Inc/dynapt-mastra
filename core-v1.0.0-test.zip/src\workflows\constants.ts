// symbol is used to not leak emitter to the user
export const EMITTER_SYMBOL = Symbol('emitter');
