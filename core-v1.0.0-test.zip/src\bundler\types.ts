export type BundlerConfig = {
  externals?: string[];
};
