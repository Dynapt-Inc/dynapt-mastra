import type { CoreTool, MastraMessageV1 } from '@mastra/core';
import type { MastraMessageV2 } from '@mastra/core/agent';
import { MastraMemory } from '@mastra/core/memory';
import type { MemoryConfig, SharedMemoryConfig, StorageThreadType, WorkingMemoryFormat, WorkingMemoryTemplate } from '@mastra/core/memory';
import type { StorageGetMessagesArg } from '@mastra/core/storage';
import type { CoreMessage, UIMessage } from 'ai';
/**
 * Concrete implementation of MastraMemory that adds support for thread configuration
 * and message injection.
 */
export declare class Memory extends MastraMemory {
    constructor(config?: SharedMemoryConfig);
    private validateThreadIsOwnedByResource;
    private checkStorageFeatureSupport;
    query({ threadId, resourceId, selectBy, threadConfig, }: StorageGetMessagesArg & {
        threadConfig?: MemoryConfig;
    }): Promise<{
        messages: CoreMessage[];
        uiMessages: UIMessage[];
        messagesV2: MastraMessageV2[];
    }>;
    rememberMessages({ threadId, resourceId, vectorMessageSearch, config, }: {
        threadId: string;
        resourceId?: string;
        vectorMessageSearch?: string;
        config?: MemoryConfig;
    }): Promise<{
        messages: MastraMessageV1[];
        messagesV2: MastraMessageV2[];
    }>;
    getThreadById({ threadId }: {
        threadId: string;
    }): Promise<StorageThreadType | null>;
    getThreadsByResourceId({ resourceId }: {
        resourceId: string;
    }): Promise<StorageThreadType[]>;
    saveThread({ thread, memoryConfig, }: {
        thread: StorageThreadType;
        memoryConfig?: MemoryConfig;
    }): Promise<StorageThreadType>;
    updateThread({ id, title, metadata, }: {
        id: string;
        title: string;
        metadata: Record<string, unknown>;
    }): Promise<StorageThreadType>;
    deleteThread(threadId: string): Promise<void>;
    private chunkText;
    private hasher;
    private embeddingCache;
    private firstEmbed;
    private embedMessageContent;
    saveMessages(args: {
        messages: (MastraMessageV1 | MastraMessageV2)[] | MastraMessageV1[] | MastraMessageV2[];
        memoryConfig?: MemoryConfig | undefined;
        format?: 'v1';
    }): Promise<MastraMessageV1[]>;
    saveMessages(args: {
        messages: (MastraMessageV1 | MastraMessageV2)[] | MastraMessageV1[] | MastraMessageV2[];
        memoryConfig?: MemoryConfig | undefined;
        format: 'v2';
    }): Promise<MastraMessageV2[]>;
    protected updateMessageToHideWorkingMemory(message: MastraMessageV1): MastraMessageV1 | null;
    protected updateMessageToHideWorkingMemoryV2(message: MastraMessageV2): MastraMessageV2 | null;
    protected parseWorkingMemory(text: string): string | null;
    getWorkingMemory({ threadId, format, }: {
        threadId: string;
        format?: WorkingMemoryFormat;
    }): Promise<string | null>;
    getWorkingMemoryTemplate(): Promise<WorkingMemoryTemplate | null>;
    getSystemMessage({ threadId, memoryConfig, }: {
        threadId: string;
        memoryConfig?: MemoryConfig;
    }): Promise<string | null>;
    getUserContextMessage({ threadId }: {
        threadId: string;
    }): Promise<string | null>;
    defaultWorkingMemoryTemplate: string;
    private getWorkingMemoryToolInstruction;
    getTools(config?: MemoryConfig): Record<string, CoreTool>;
    /**
     * Updates the metadata of a list of messages
     * @param messages - The list of messages to update
     * @returns The list of updated messages
     */
    updateMessages({ messages, }: {
        messages: Partial<MastraMessageV2> & {
            id: string;
        }[];
    }): Promise<MastraMessageV2[]>;
}
//# sourceMappingURL=index.d.ts.map