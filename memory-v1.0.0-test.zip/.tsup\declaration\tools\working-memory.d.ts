import type { CoreTool } from '@mastra/core';
import type { WorkingMemoryFormat } from '@mastra/core/memory';
export declare const updateWorkingMemoryTool: ({ format }: {
    format: WorkingMemoryFormat;
}) => CoreTool;
//# sourceMappingURL=working-memory.d.ts.map