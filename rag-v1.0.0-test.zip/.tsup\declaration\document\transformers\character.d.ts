import { Language } from '../types';
import type { ChunkOptions } from '../types';
import { TextTransformer } from './text';
export declare class CharacterTransformer extends TextTransformer {
    protected separator: string;
    protected isSeparatorRegex: boolean;
    constructor({ separator, isSeparatorRegex, options, }: {
        separator?: string;
        isSeparatorRegex?: boolean;
        options?: {
            size?: number;
            overlap?: number;
            lengthFunction?: (text: string) => number;
            keepSeparator?: boolean | 'start' | 'end';
            addStartIndex?: boolean;
            stripWhitespace?: boolean;
        };
    });
    splitText({ text }: {
        text: string;
    }): string[];
    private __splitChunk;
}
export declare class RecursiveCharacterTransformer extends TextTransformer {
    protected separators: string[];
    protected isSeparatorRegex: boolean;
    constructor({ separators, isSeparatorRegex, options, }: {
        separators?: string[];
        isSeparatorRegex?: boolean;
        options?: ChunkOptions;
    });
    private _splitText;
    splitText({ text }: {
        text: string;
    }): string[];
    static fromLanguage(language: Language, options?: {
        size?: number;
        chunkOverlap?: number;
        lengthFunction?: (text: string) => number;
        keepSeparator?: boolean | 'start' | 'end';
        addStartIndex?: boolean;
        stripWhitespace?: boolean;
    }): RecursiveCharacterTransformer;
    static getSeparatorsForLanguage(language: Language): string[];
}
//# sourceMappingURL=character.d.ts.map