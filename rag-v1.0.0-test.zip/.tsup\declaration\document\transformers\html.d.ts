import { Document } from '../schema';
export declare class HTMLHeaderTransformer {
    private headersToSplitOn;
    private returnEachElement;
    constructor(headersToSplitOn: [string, string][], returnEachElement?: boolean);
    splitText({ text }: {
        text: string;
    }): Document[];
    private getXPath;
    private getTextContent;
    private aggregateElementsToChunks;
    createDocuments(texts: string[], metadatas?: Record<string, any>[]): Document[];
    transformDocuments(documents: Document[]): Document[];
}
export declare class HTMLSectionTransformer {
    private headersToSplitOn;
    private options;
    constructor(headersToSplitOn: [string, string][], options?: Record<string, any>);
    splitText(text: string): Document[];
    private getXPath;
    private splitHtmlByHeaders;
    splitDocuments(documents: Document[]): Promise<Document[]>;
    createDocuments(texts: string[], metadatas?: Record<string, any>[]): Document[];
    transformDocuments(documents: Document[]): Document[];
}
//# sourceMappingURL=html.d.ts.map