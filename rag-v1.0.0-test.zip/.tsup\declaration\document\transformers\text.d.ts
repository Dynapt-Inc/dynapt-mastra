import { Document } from '../schema';
import type { ChunkOptions } from '../types';
import type { Transformer } from './transformer';
export declare abstract class TextTransformer implements Transformer {
    protected size: number;
    protected overlap: number;
    protected lengthFunction: (text: string) => number;
    protected keepSeparator: boolean | 'start' | 'end';
    protected addStartIndex: boolean;
    protected stripWhitespace: boolean;
    constructor({ size, overlap, lengthFunction, keepSeparator, addStartIndex, stripWhitespace, }: ChunkOptions);
    setAddStartIndex(value: boolean): void;
    abstract splitText({ text }: {
        text: string;
    }): string[];
    createDocuments(texts: string[], metadatas?: Record<string, any>[]): Document[];
    splitDocuments(documents: Document[]): Document[];
    transformDocuments(documents: Document[]): Document[];
    protected joinDocs(docs: string[], separator: string): string | null;
    protected mergeSplits(splits: string[], separator: string): string[];
}
//# sourceMappingURL=text.d.ts.map