import { RecursiveCharacterTransformer } from './character';
export declare class LatexTransformer extends RecursiveCharacterTransformer {
    constructor(options?: {
        size?: number;
        overlap?: number;
        lengthFunction?: (text: string) => number;
        keepSeparator?: boolean | 'start' | 'end';
        addStartIndex?: boolean;
        stripWhitespace?: boolean;
    });
}
//# sourceMappingURL=latex.d.ts.map