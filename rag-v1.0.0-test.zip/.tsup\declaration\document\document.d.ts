import { Document as Chunk } from './schema';
import type { ChunkOptions, ChunkParams, ExtractParams } from './types';
export declare class MDocument {
    private chunks;
    private type;
    constructor({ docs, type }: {
        docs: {
            text: string;
            metadata?: Record<string, any>;
        }[];
        type: string;
    });
    extractMetadata({ title, summary, questions, keywords }: ExtractParams): Promise<MDocument>;
    static fromText(text: string, metadata?: Record<string, any>): MDocument;
    static fromHTML(html: string, metadata?: Record<string, any>): MDocument;
    static fromMarkdown(markdown: string, metadata?: Record<string, any>): MDocument;
    static fromJSON(jsonString: string, metadata?: Record<string, any>): MDocument;
    private defaultStrategy;
    private chunkBy;
    chunkRecursive(options?: ChunkOptions): Promise<void>;
    chunkCharacter(options?: ChunkOptions): Promise<void>;
    chunkHTML(options?: ChunkOptions): Promise<void>;
    chunkJSON(options?: ChunkOptions): Promise<void>;
    chunkLatex(options?: ChunkOptions): Promise<void>;
    chunkToken(options?: ChunkOptions): Promise<void>;
    chunkMarkdown(options?: ChunkOptions): Promise<void>;
    chunk(params?: ChunkParams): Promise<Chunk[]>;
    getDocs(): Chunk[];
    getText(): string[];
    getMetadata(): Record<string, any>[];
}
//# sourceMappingURL=document.d.ts.map