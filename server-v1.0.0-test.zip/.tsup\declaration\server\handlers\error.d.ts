export declare function handleError(error: unknown, defaultMessage: string): never;
//# sourceMappingURL=error.d.ts.map