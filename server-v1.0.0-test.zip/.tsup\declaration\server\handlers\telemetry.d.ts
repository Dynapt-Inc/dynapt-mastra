import type { Context } from '../types';
interface TelemetryContext extends Context {
    body?: {
        name?: string;
        scope?: string;
        page?: number;
        perPage?: number;
        attribute?: string | string[];
        fromDate?: Date;
        toDate?: Date;
    };
}
export declare function getTelemetryHandler({ mastra, body }: TelemetryContext): Promise<any[]>;
export declare function storeTelemetryHandler({ mastra, body }: Context & {
    body: {
        resourceSpans: any[];
    };
}): Promise<{
    status: string;
    message: string;
    error: any;
} | {
    status: string;
    message: string;
    traceCount?: undefined;
} | {
    status: string;
    message: string;
    traceCount: number;
}>;
export {};
//# sourceMappingURL=telemetry.d.ts.map