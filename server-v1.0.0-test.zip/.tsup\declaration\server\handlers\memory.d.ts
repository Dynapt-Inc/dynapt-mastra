import type { MastraMemory } from '@mastra/core/memory';
import type { Context } from '../types';
interface MemoryContext extends Context {
    agentId?: string;
    resourceId?: string;
    threadId?: string;
}
export declare function getMemoryStatusHandler({ mastra, agentId }: Pick<MemoryContext, 'mastra' | 'agentId'>): Promise<{
    result: boolean;
}>;
export declare function getThreadsHandler({ mastra, agentId, resourceId, }: Pick<MemoryContext, 'mastra' | 'agentId' | 'resourceId'>): Promise<import("@mastra/core/memory").StorageThreadType[]>;
export declare function getThreadByIdHandler({ mastra, agentId, threadId, }: Pick<MemoryContext, 'mastra' | 'agentId' | 'threadId'>): Promise<import("@mastra/core/memory").StorageThreadType>;
export declare function saveMessagesHandler({ mastra, agentId, body, }: Pick<MemoryContext, 'mastra' | 'agentId'> & {
    body: {
        messages: Parameters<MastraMemory['saveMessages']>[0]['messages'];
    };
}): Promise<import("@mastra/core/memory").MastraMessageV1[]>;
export declare function createThreadHandler({ mastra, agentId, body, }: Pick<MemoryContext, 'mastra' | 'agentId'> & {
    body?: Omit<Parameters<MastraMemory['createThread']>[0], 'resourceId'> & {
        resourceId?: string;
    };
}): Promise<import("@mastra/core/memory").StorageThreadType>;
export declare function updateThreadHandler({ mastra, agentId, threadId, body, }: Pick<MemoryContext, 'mastra' | 'agentId' | 'threadId'> & {
    body?: Parameters<MastraMemory['saveThread']>[0]['thread'];
}): Promise<import("@mastra/core/memory").StorageThreadType>;
export declare function deleteThreadHandler({ mastra, agentId, threadId, }: Pick<MemoryContext, 'mastra' | 'agentId' | 'threadId'>): Promise<{
    result: string;
}>;
export declare function getMessagesHandler({ mastra, agentId, threadId, limit, }: Pick<MemoryContext, 'mastra' | 'agentId' | 'threadId'> & {
    limit?: number;
}): Promise<{
    messages: import("ai").CoreMessage[];
    uiMessages: import("ai").UIMessage[];
}>;
export {};
//# sourceMappingURL=memory.d.ts.map