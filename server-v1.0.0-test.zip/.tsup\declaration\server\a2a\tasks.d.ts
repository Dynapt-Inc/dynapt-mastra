import type { Message, TaskContext, TaskAndHistory, Task, TaskStatus, Artifact } from '@mastra/core/a2a';
import type { IMastraLogger } from '@mastra/core/logger';
import type { InMemoryTaskStore } from './store';
export declare function applyUpdateToTaskAndHistory(current: TaskAndHistory, update: Omit<TaskStatus, 'timestamp'> | Artifact): TaskAndHistory;
export declare function loadOrCreateTaskAndHistory({ agentId, taskId, taskStore, message, sessionId, metadata, logger, }: {
    agentId: string;
    taskId: string;
    taskStore: InMemoryTaskStore;
    message: Message;
    sessionId?: string | null;
    metadata?: Record<string, unknown> | null;
    logger?: IMastraLogger;
}): Promise<TaskAndHistory>;
export declare function createTaskContext({ task, userMessage, history, activeCancellations, }: {
    task: Task;
    userMessage: Message;
    history: Message[];
    activeCancellations: Set<string>;
}): TaskContext;
//# sourceMappingURL=tasks.d.ts.map