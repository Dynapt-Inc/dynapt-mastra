import type { RuntimeContext } from '@mastra/core/di';
import type { ToolAction, VercelTool } from '@mastra/core/tools';
import type { Context } from '../types';
interface ToolsContext extends Context {
    tools?: Record<string, ToolAction | VercelTool>;
    toolId?: string;
    runId?: string;
}
export declare function getToolsHandler({ tools }: Pick<ToolsContext, 'tools'>): Promise<Record<string, any>>;
export declare function getToolByIdHandler({ tools, toolId }: Pick<ToolsContext, 'tools' | 'toolId'>): Promise<any>;
export declare function executeToolHandler(tools: ToolsContext['tools']): ({ mastra, runId, toolId, data, runtimeContext, }: Pick<ToolsContext, "mastra" | "toolId" | "runId"> & {
    data?: unknown;
    runtimeContext: RuntimeContext;
}) => Promise<any>;
export declare function executeAgentToolHandler({ mastra, agentId, toolId, data, runtimeContext, }: Pick<ToolsContext, 'mastra' | 'toolId'> & {
    agentId?: string;
    data: any;
    runtimeContext: RuntimeContext;
}): Promise<any>;
export {};
//# sourceMappingURL=tools.d.ts.map