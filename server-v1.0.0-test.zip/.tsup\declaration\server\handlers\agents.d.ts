import type { Agent } from '@mastra/core/agent';
import { RuntimeContext } from '@mastra/core/runtime-context';
import type { Context } from '../types';
type GetBody<T extends keyof Agent & {
    [K in keyof Agent]: Agent[K] extends (...args: any) => any ? K : never;
}[keyof Agent]> = {
    messages: Parameters<Agent[T]>[0];
} & Parameters<Agent[T]>[1];
export declare function getAgentsHandler({ mastra, runtimeContext }: Context & {
    runtimeContext: RuntimeContext;
}): Promise<any>;
export declare function getAgentByIdHandler({ mastra, runtimeContext, agentId, isPlayground, }: Context & {
    isPlayground?: boolean;
    runtimeContext: RuntimeContext;
    agentId: string;
}): Promise<{
    name: any;
    instructions: string;
    tools: any;
    workflows: {};
    provider: string;
    modelId: string;
    defaultGenerateOptions: any;
    defaultStreamOptions: any;
}>;
export declare function getEvalsByAgentIdHandler({ mastra, runtimeContext, agentId, }: Context & {
    runtimeContext: RuntimeContext;
    agentId: string;
}): Promise<{
    id: string;
    name: any;
    instructions: string;
    evals: import("@mastra/core/storage").EvalRow[];
}>;
export declare function getLiveEvalsByAgentIdHandler({ mastra, runtimeContext, agentId, }: Context & {
    runtimeContext: RuntimeContext;
    agentId: string;
}): Promise<{
    id: string;
    name: any;
    instructions: string;
    evals: import("@mastra/core/storage").EvalRow[];
}>;
export declare function generateHandler({ mastra, runtimeContext, agentId, body, }: Context & {
    runtimeContext: RuntimeContext;
    agentId: string;
    body: GetBody<'generate'> & {
        resourceid?: string;
        runtimeContext?: Record<string, unknown>;
    };
}): Promise<import("ai").GenerateTextResult<any, unknown>>;
export declare function streamGenerateHandler({ mastra, runtimeContext, agentId, body, }: Context & {
    runtimeContext: RuntimeContext;
    agentId: string;
    body: GetBody<'stream'> & {
        resourceid?: string;
        runtimeContext?: string;
    };
}): Promise<Response | undefined>;
export {};
//# sourceMappingURL=agents.d.ts.map