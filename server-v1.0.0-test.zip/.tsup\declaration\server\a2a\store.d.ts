import type { TaskAndHistory } from '@mastra/core/a2a';
export declare class InMemoryTaskStore {
    private store;
    activeCancellations: Set<string>;
    load({ agentId, taskId }: {
        agentId: string;
        taskId: string;
    }): Promise<TaskAndHistory | null>;
    save({ agentId, data }: {
        agentId: string;
        data: TaskAndHistory;
    }): Promise<void>;
}
//# sourceMappingURL=store.d.ts.map