export declare const GLOBAL_RUN_ID_ENV_KEY = "_MASTRA_GLOBAL_RUN_ID_";
//# sourceMappingURL=constants.d.ts.map