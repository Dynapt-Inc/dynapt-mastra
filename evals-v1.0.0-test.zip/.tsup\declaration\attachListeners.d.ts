import type { Mastra } from '@mastra/core';
export declare function attachListeners(mastra?: Mastra): Promise<void>;
export declare function globalSetup(): Promise<void>;
//# sourceMappingURL=attachListeners.d.ts.map