import { Metric } from '@mastra/core/eval';
import type { LanguageModel } from '@mastra/core/llm';
import type { MetricResultWithReason } from '../types';
export interface ContextPositionMetricOptions {
    scale?: number;
    context: string[];
}
export declare class ContextPositionMetric extends Metric {
    private judge;
    private scale;
    private context;
    constructor(model: LanguageModel, { scale, context }: ContextPositionMetricOptions);
    measure(input: string, output: string): Promise<MetricResultWithReason>;
    private calculateScore;
}
//# sourceMappingURL=index.d.ts.map