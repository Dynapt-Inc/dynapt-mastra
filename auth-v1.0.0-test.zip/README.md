# @mastra/auth

Core Auth methods for Mastra applications.

## Installation

```bash
npm install @mastra/auth
```
