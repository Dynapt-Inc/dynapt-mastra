#!/usr/bin/env node
export {};
//# sourceMappingURL=stdio.d.ts.map