export {};
//# sourceMappingURL=pulse.test.d.ts.map