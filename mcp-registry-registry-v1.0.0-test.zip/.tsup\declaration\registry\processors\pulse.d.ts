import type { ServerEntry } from '../types';
/**
 * Post-processor for Pulse MCP registry
 * Handles the specific format of Pulse MCP's server data
 */
export declare function processPulseMcpServers(data: any): ServerEntry[];
//# sourceMappingURL=pulse.d.ts.map