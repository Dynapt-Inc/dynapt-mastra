import type { ServerEntry } from '../types';
/**
 * Post-processor for Docker MCP Hub registry
 * Transforms Docker Hub API response into standardized ServerEntry format
 */
export declare function processDockerServers(data: unknown): ServerEntry[];
//# sourceMappingURL=docker.d.ts.map