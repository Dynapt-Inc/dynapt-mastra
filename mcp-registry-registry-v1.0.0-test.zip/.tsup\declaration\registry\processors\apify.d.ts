import type { ServerEntry } from '../types';
/**
 * Post-processor for Apify registry
 * Handles the specific format of Apify's store data
 */
export declare function processApifyServers(data: any): ServerEntry[];
//# sourceMappingURL=apify.d.ts.map