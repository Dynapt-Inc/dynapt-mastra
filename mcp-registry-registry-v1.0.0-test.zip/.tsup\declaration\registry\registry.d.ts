import type { RegistryFile } from './types';
export declare const registryData: RegistryFile;
//# sourceMappingURL=registry.d.ts.map