import type { ServerEntry } from '../types';
/**
 * Post-processor for APITracker registry
 * Handles the specific format of APITracker's server data
 */
export declare function processApiTrackerServers(data: unknown): ServerEntry[];
//# sourceMappingURL=apitracker.d.ts.map