export {};
//# sourceMappingURL=list-registries.test.d.ts.map