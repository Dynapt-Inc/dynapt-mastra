export {};
//# sourceMappingURL=fetch-servers.test.d.ts.map