export declare function fromPackageRoot(relativePath: string): string;
//# sourceMappingURL=utils.d.ts.map