import type { ServerEntry } from '../types';
/**
 * Post-processor for Fleur registry
 * Handles the specific format of Fleur's app data
 */
export declare function processFleurServers(data: unknown): ServerEntry[];
//# sourceMappingURL=fleur.d.ts.map