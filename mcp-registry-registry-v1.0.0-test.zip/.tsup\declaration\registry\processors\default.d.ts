import type { ServerEntry } from '../types';
/**
 * Default processor for registry server data
 * Handles common formats that might be encountered
 */
export declare function processDefaultServers(data: unknown): ServerEntry[];
//# sourceMappingURL=default.d.ts.map