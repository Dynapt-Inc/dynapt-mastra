export * from './registry/registry';
//# sourceMappingURL=index.d.ts.map