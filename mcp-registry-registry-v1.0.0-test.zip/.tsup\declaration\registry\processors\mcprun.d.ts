import type { ServerEntry } from '../types';
export declare function processMcpRunServers(data: any): ServerEntry[];
//# sourceMappingURL=mcprun.d.ts.map