import type { ServerEntry } from '../types';
export declare function createServerEntry(data: Record<string, unknown>): ServerEntry;
//# sourceMappingURL=utils.d.ts.map