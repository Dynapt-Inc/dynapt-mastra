export {};
//# sourceMappingURL=docker.test.d.ts.map