export {};
//# sourceMappingURL=openapi.script.d.ts.map