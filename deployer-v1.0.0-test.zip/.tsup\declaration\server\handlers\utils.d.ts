export declare function validateBody(body: Record<string, unknown>): void;
//# sourceMappingURL=utils.d.ts.map