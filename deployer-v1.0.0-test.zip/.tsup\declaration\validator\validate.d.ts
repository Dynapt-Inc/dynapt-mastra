export declare function validate(file: string): Promise<void>;
//# sourceMappingURL=validate.d.ts.map