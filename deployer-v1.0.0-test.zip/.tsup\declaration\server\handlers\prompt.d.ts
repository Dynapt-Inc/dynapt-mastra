import type { Context } from 'hono';
export declare function generateSystemPromptHandler(c: Context): Promise<Response>;
//# sourceMappingURL=prompt.d.ts.map