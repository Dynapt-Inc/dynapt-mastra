import type { Context } from 'hono';
export declare function getLogsHandler(c: Context): Promise<Response>;
export declare function getLogsByRunIdHandler(c: Context): Promise<Response>;
export declare function getLogTransports(c: Context): Promise<Response>;
//# sourceMappingURL=logs.d.ts.map