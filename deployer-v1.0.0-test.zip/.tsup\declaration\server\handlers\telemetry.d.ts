import type { Context } from 'hono';
export declare function getTelemetryHandler(c: Context): Promise<Response>;
export declare function storeTelemetryHandler(c: Context): Promise<Response>;
//# sourceMappingURL=telemetry.d.ts.map