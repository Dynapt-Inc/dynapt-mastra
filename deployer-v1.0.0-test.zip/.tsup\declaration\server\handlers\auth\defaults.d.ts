import type { MastraAuthConfig } from '@mastra/core/server';
export declare const defaultAuthConfig: MastraAuthConfig;
//# sourceMappingURL=defaults.d.ts.map