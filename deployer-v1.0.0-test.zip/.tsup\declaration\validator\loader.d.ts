export {};
//# sourceMappingURL=loader.d.ts.map