import type { MastraAuthConfig } from '@mastra/core/server';
export declare const isProtectedPath: (path: string, method: string, authConfig: MastraAuthConfig) => boolean;
export declare const canAccessPublicly: (path: string, method: string, authConfig: MastraAuthConfig) => boolean;
export declare const pathMatchesPattern: (path: string, pattern: string) => boolean;
export declare const pathMatchesRule: (path: string, rulePath: string | RegExp | string[] | undefined) => boolean;
export declare const matchesOrIncludes: (values: string | string[], value: string) => boolean;
export declare const checkRules: (rules: MastraAuthConfig["rules"], path: string, method: string, user: unknown) => Promise<boolean>;
//# sourceMappingURL=helpers.d.ts.map