import type { Mastra } from '@mastra/core';
import { RuntimeContext } from '@mastra/core/runtime-context';
import { Hono } from 'hono';
import type { ServerBundleOptions } from './types';
type Bindings = {};
type Variables = {
    mastra: Mastra;
    runtimeContext: RuntimeContext;
    clients: Set<{
        controller: ReadableStreamDefaultController;
    }>;
    tools: Record<string, any>;
    playground: boolean;
    isDev: boolean;
};
export declare function createHonoServer(mastra: Mastra, options?: ServerBundleOptions): Promise<Hono<{
    Bindings: Bindings;
    Variables: Variables;
}, import("hono/types").BlankSchema, "/">>;
export declare function createNodeServer(mastra: Mastra, options?: ServerBundleOptions): Promise<import("@hono/node-server").ServerType>;
export {};
//# sourceMappingURL=index.d.ts.map