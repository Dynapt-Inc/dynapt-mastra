import type { Context } from 'hono';
export declare function getWorkflowsHandler(c: Context): Promise<Response>;
export declare function getWorkflowByIdHandler(c: Context): Promise<Response>;
export declare function createWorkflowRunHandler(c: Context): Promise<Response>;
export declare function startAsyncWorkflowHandler(c: Context): Promise<Response>;
export declare function startWorkflowRunHandler(c: Context): Promise<Response>;
export declare function watchWorkflowHandler(c: Context): Response | Promise<Response>;
export declare function streamWorkflowHandler(c: Context): Promise<Response>;
export declare function resumeAsyncWorkflowHandler(c: Context): Promise<Response>;
export declare function resumeWorkflowHandler(c: Context): Promise<Response>;
export declare function getWorkflowRunsHandler(c: Context): Promise<Response>;
export declare function getWorkflowRunByIdHandler(c: Context): Promise<Response>;
export declare function getWorkflowRunExecutionResultHandler(c: Context): Promise<Response>;
//# sourceMappingURL=workflows.d.ts.map