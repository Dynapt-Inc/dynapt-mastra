import { Transform } from 'stream';
import type { IMastraLogger } from '@mastra/core/logger';
export declare const createPinoStream: (logger: IMastraLogger) => Transform;
export declare function createChildProcessLogger({ logger, root }: {
    logger: IMastraLogger;
    root: string;
}): ({ cmd, args, env }: {
    cmd: string;
    args: string[];
    env: Record<string, string>;
}) => Promise<unknown>;
//# sourceMappingURL=log.d.ts.map