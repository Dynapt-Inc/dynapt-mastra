import type { Context } from 'hono';
export declare function rootHandler(c: Context): Promise<Response & import("hono").TypedResponse<"Hello to the Mastra API!", import("hono/utils/http-status").ContentfulStatusCode, "text">>;
//# sourceMappingURL=root.d.ts.map