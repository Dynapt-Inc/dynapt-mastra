import type { Context } from 'hono';
export declare function getNetworksHandler(c: Context): Promise<Response>;
export declare function getNetworkByIdHandler(c: Context): Promise<Response>;
export declare function generateHandler(c: Context): Promise<Response>;
export declare function streamGenerateHandler(c: Context): Promise<Response | undefined>;
//# sourceMappingURL=network.d.ts.map