import type { Context } from 'hono';
export declare function getMemoryStatusHandler(c: Context): Promise<Response>;
export declare function getThreadsHandler(c: Context): Promise<Response>;
export declare function getThreadByIdHandler(c: Context): Promise<Response>;
export declare function saveMessagesHandler(c: Context): Promise<Response>;
export declare function createThreadHandler(c: Context): Promise<Response>;
export declare function updateThreadHandler(c: Context): Promise<Response>;
export declare function deleteThreadHandler(c: Context): Promise<Response>;
export declare function getMessagesHandler(c: Context): Promise<Response>;
//# sourceMappingURL=memory.d.ts.map