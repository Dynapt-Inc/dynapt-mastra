import type { Context } from 'hono';
export declare function getAgentCardByIdHandler(c: Context): Promise<Response & import("hono").TypedResponse<{
    name: string;
    description?: string | null | undefined;
    url: string;
    provider?: {
        organization: string;
        url?: string | null | undefined;
    } | null | undefined;
    version: string;
    documentationUrl?: string | null | undefined;
    capabilities: {
        streaming?: boolean | undefined;
        pushNotifications?: boolean | undefined;
        stateTransitionHistory?: boolean | undefined;
    };
    authentication?: {
        schemes: string[];
        credentials?: string | null | undefined;
    } | null | undefined;
    defaultInputModes?: string[] | undefined;
    defaultOutputModes?: string[] | undefined;
    skills: {
        id: string;
        name: string;
        description?: string | null | undefined;
        tags?: string[] | null | undefined;
        examples?: string[] | null | undefined;
        inputModes?: string[] | null | undefined;
        outputModes?: string[] | null | undefined;
    }[];
}, import("hono/utils/http-status").ContentfulStatusCode, "json">>;
export declare function getAgentExecutionHandler(c: Context): Promise<Response>;
//# sourceMappingURL=a2a.d.ts.map