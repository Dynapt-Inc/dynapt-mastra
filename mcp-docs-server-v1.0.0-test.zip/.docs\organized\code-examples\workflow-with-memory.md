### package.json
```json
{
  "name": "examples-workflow-with-memory",
  "type": "module",
  "private": true,
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "keywords": [],
  "author": "",
  "license": "MIT",
  "description": "",
  "devDependencies": {
    "@types/node": "^20.17.57",
    "tsx": "^4.19.3",
    "typescript": "^5.8.2",
    "zod": "^3.25.56"
  },
  "dependencies": {
    "@ai-sdk/openai": "latest",
    "@mastra/core": "latest",
    "@mastra/memory": "latest",
    "@mastra/pg": "latest"
  },
  "version": "0.0.1",
  "pnpm": {
    "overrides": {
      "@mastra/core": "link:../../packages/core",
      "@mastra/memory": "link:../../packages/memory",
      "@mastra/pg": "link:../../stores/pg"
    }
  },
  "packageManager": "pnpm@10.10.0+sha512.d615db246fe70f25dcfea6d8d73dee782ce23e2245e3c4f6f888249fb568149318637dca73c2c5c8ef2a4ca0d5657fb9567188bfab47f566d1ee6ce987815c39"
}

```

### mastra\agents\index.ts
```typescript
import { openai } from '@ai-sdk/openai';
import { Agent } from '@mastra/core/agent';
import { Memory } from '@mastra/memory';
import { PostgresStore } from '@mastra/pg';

const connectionString = process.env.POSTGRES_URL!;
const memory = new Memory({
  storage: new PostgresStore({ connectionString }),
});

export const catOne = new Agent({
  name: 'cat-one',
  memory,
  instructions:
    'You are a feline expert with comprehensive knowledge of all cat species, from domestic breeds to wild big cats. As a lifelong cat specialist, you understand their behavior, biology, social structures, and evolutionary history in great depth.',
  model: openai('gpt-4o'),
});

```

### mastra\index.ts
```typescript
import { Mastra } from '@mastra/core';
import { PinoLogger } from '@mastra/loggers';

import { catOne } from './agents/index';
import { sequentialWorkflow, parallelWorkflow, branchedWorkflow, cyclicalWorkflow } from './workflows';

export const mastra = new Mastra({
  agents: { catOne },
  logger: new PinoLogger({
    name: 'Mastra',
    level: 'debug',
  }),
  workflows: {
    sequentialWorkflow,
    parallelWorkflow,
    branchedWorkflow,
    cyclicalWorkflow,
  },
});

```

### mastra\tools\index.ts
```typescript
import { createTool } from '@mastra/core/tools';
import { z } from 'zod';

const getCatFact = async () => {
  const { fact } = (await fetch('https://catfact.ninja/fact').then(res => res.json())) as {
    fact: string;
  };
  return fact;
};

export const catFact = createTool({
  id: 'Get cat facts',
  inputSchema: z.object({}),
  description: 'Fetches cat facts',
  execute: async () => {
    console.log('using tool to fetch cat fact');
    return {
      catFact: await getCatFact(),
    };
  },
});

```

### mastra\workflows\index.ts
```typescript
import { Workflow, Step } from '@mastra/core/workflows';
import { z } from 'zod';

const stepOne = new Step({
  id: 'stepOne',
  description: 'Doubles the input value',
  inputSchema: z.object({
    inputValue: z.number(),
  }),
  outputSchema: z.object({
    doubledValue: z.number(),
  }),
  execute: async ({ context }) => {
    const doubledValue = context.inputValue * 2;
    return { doubledValue };
  },
});

const stepTwo = new Step({
  id: 'stepTwo',
  description: 'Adds 1 to the input value',
  inputSchema: z.object({
    valueToIncrement: z.number(),
  }),
  outputSchema: z.object({
    incrementedValue: z.number(),
  }),
  execute: async ({ context }) => {
    const incrementedValue = context.valueToIncrement + 1;
    return { incrementedValue };
  },
});

const stepThree = new Step({
  id: 'stepThree',
  description: 'Squares the input value',
  inputSchema: z.object({
    valueToSquare: z.number(),
  }),
  outputSchema: z.object({
    squaredValue: z.number(),
  }),
  execute: async ({ context }) => {
    const squaredValue = context.valueToSquare * context.valueToSquare;
    return { squaredValue };
  },
});

const stepFour = new Step({
  id: 'stepFour',
  description: 'Gives the square root of the input value',
  inputSchema: z.object({
    valueToRoot: z.number(),
  }),
  outputSchema: z.object({
    rootValue: z.number(),
  }),
  execute: async ({ context }) => {
    return { rootValue: Math.sqrt(context.valueToRoot) };
  },
});

const stepFive = new Step({
  id: 'stepFive',
  description: 'Triples the input value',
  inputSchema: z.object({
    inputValue: z.number(),
  }),
  outputSchema: z.object({
    tripledValue: z.number(),
  }),
  execute: async ({ context }) => {
    const tripledValue = context.inputValue * 3;
    return { tripledValue };
  },
});

const stepSix = new Step({
  id: 'stepSix',
  description: 'Logs the input value',
  inputSchema: z.object({
    inputValue: z.number(),
  }),
  outputSchema: z.object({
    rawText: z.string(),
  }),
  execute: async ({ context }) => {
    console.log(context.inputValue);
    return { rawText: context.inputValue.toString() };
  },
});

export const sequentialWorkflow = new Workflow({
  name: 'sequential-workflow',
  triggerSchema: z.object({
    firstValue: z.number(),
  }),
});

sequentialWorkflow
  .step(stepOne, {
    variables: {
      inputValue: {
        step: 'trigger',
        path: 'firstValue',
      },
    },
  })
  .then(stepTwo, {
    variables: {
      valueToIncrement: {
        step: stepOne,
        path: 'doubledValue',
      },
    },
  })
  .then(stepThree, {
    variables: {
      valueToSquare: {
        step: stepTwo,
        path: 'incrementedValue',
      },
    },
  })
  .then(stepFour, {
    variables: {
      valueToRoot: {
        step: stepThree,
        path: 'squaredValue',
      },
    },
  })
  .then(stepFive, {
    variables: {
      inputValue: {
        step: stepFour,
        path: 'rootValue',
      },
    },
  });

sequentialWorkflow.commit();

export const parallelWorkflow = new Workflow({
  name: 'parallel-workflow',
  triggerSchema: z.object({
    firstValue: z.number(),
  }),
});

parallelWorkflow
  .step(stepOne, {
    variables: {
      inputValue: {
        step: 'trigger',
        path: 'firstValue',
      },
    },
  })
  .then(stepSix, {
    variables: {
      inputValue: {
        step: stepOne,
        path: 'doubledValue',
      },
    },
  })
  .step(stepTwo, {
    variables: {
      valueToIncrement: {
        step: 'trigger',
        path: 'firstValue',
      },
    },
  })
  .step(stepThree, {
    variables: {
      valueToSquare: {
        step: 'trigger',
        path: 'firstValue',
      },
    },
  });

parallelWorkflow.commit();

export const branchedWorkflow = new Workflow({
  name: 'branched-workflow',
  triggerSchema: z.object({
    firstValue: z.number(),
  }),
});

branchedWorkflow
  .step(stepOne, {
    variables: {
      inputValue: {
        step: 'trigger',
        path: 'firstValue',
      },
    },
  })
  .then(stepTwo, {
    variables: {
      valueToIncrement: {
        step: stepOne,
        path: 'doubledValue',
      },
    },
  })
  .then(stepFour, {
    variables: {
      valueToRoot: {
        step: stepTwo,
        path: 'incrementedValue',
      },
    },
  })
  .after(stepOne)
  .step(stepThree, {
    variables: {
      valueToSquare: {
        step: stepOne,
        path: 'doubledValue',
      },
    },
  })
  .then(stepFive, {
    variables: {
      inputValue: {
        step: stepThree,
        path: 'squaredValue',
      },
    },
  });

branchedWorkflow.commit();

export const cyclicalWorkflow = new Workflow({
  name: 'cyclical-workflow',
  triggerSchema: z.object({
    firstValue: z.number(),
  }),
});

cyclicalWorkflow
  .step(stepOne, {
    variables: {
      inputValue: {
        step: 'trigger',
        path: 'firstValue',
      },
    },
  })
  .then(stepTwo, {
    variables: {
      valueToIncrement: {
        step: 'trigger',
        path: 'firstValue',
      },
    },
  })
  .after(stepOne)
  .step(stepThree, {
    when: { ref: { step: stepOne, path: 'doubledValue' }, query: { $lte: 6 } },
    variables: {
      valueToSquare: {
        step: stepOne,
        path: 'doubledValue',
      },
    },
  })
  .step(stepOne, {
    when: {
      ref: { step: stepOne, path: 'doubledValue' },
      query: { $lte: 120000 },
    },
    variables: {
      inputValue: {
        step: stepOne,
        path: 'doubledValue',
      },
    },
  });

cyclicalWorkflow.commit();

```
