import { MCPServer } from '@mastra/mcp';
declare let server: MCPServer;
declare function runServer(): Promise<void>;
export { runServer, server };
//# sourceMappingURL=index.d.ts.map