/**
 * Scans package directories and creates organized changelog files
 */
export declare function preparePackageChanges(): Promise<void>;
//# sourceMappingURL=package-changes.d.ts.map