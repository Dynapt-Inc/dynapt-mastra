### package.json
```json
{
  "name": "memory-with-mem0",
  "version": "1.0.0",
  "main": "index.js",
  "private": true,
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1",
    "dev": "mastra dev"
  },
  "keywords": [],
  "author": "",
  "license": "MIT",
  "description": "",
  "type": "module",
  "dependencies": {
    "@ai-sdk/openai": "latest",
    "@mastra/core": "latest",
    "@mastra/mem0": "latest",
    "zod": "^3.25.56"
  },
  "pnpm": {
    "overrides": {
      "@mastra/core": "link:../../packages/core",
      "@mastra/mem0": "link:../../integrations/mem0"
    }
  },
  "devDependencies": {
    "@types/node": "^22.15.29",
    "tsx": "^4.19.3",
    "typescript": "^5.8.2"
  },
  "packageManager": "pnpm@10.10.0+sha512.d615db246fe70f25dcfea6d8d73dee782ce23e2245e3c4f6f888249fb568149318637dca73c2c5c8ef2a4ca0d5657fb9567188bfab47f566d1ee6ce987815c39"
}

```

### mastra\agents\index.ts
```typescript
import { openai } from '@ai-sdk/openai';
import { Agent } from '@mastra/core/agent';
import { mem0MemorizeTool, mem0RememberTool } from '../tools';

export const mem0Agent = new Agent({
  name: 'Mem0 Agent',
  instructions: `
    You are a helpful assistant that has the ability to memorize and remember facts using Mem0.
  `,
  model: openai('gpt-4o'),
  tools: { mem0RememberTool, mem0MemorizeTool },
});

```

### mastra\index.ts
```typescript
import { Mastra } from '@mastra/core/mastra';
import { PinoLogger } from '@mastra/loggers';

import { mem0Agent } from './agents';

export const mastra = new Mastra({
  agents: { mem0Agent },
  logger: new PinoLogger({
    name: 'Mastra',
    level: 'error',
  }),
});

```

### mastra\integrations\index.ts
```typescript
import { Mem0Integration } from '@mastra/mem0';

export const mem0 = new Mem0Integration({
  config: {
    apiKey: process.env.MEM0_API_KEY || '',
    user_id: 'alice',
  },
});

```

### mastra\tools\index.ts
```typescript
import { createTool } from '@mastra/core/tools';
import { z } from 'zod';
import { mem0 } from '../integrations';

export const mem0RememberTool = createTool({
  id: 'Mem0-remember',
  description: "Remember your agent memories that you've previously saved using the Mem0-memorize tool.",
  inputSchema: z.object({
    question: z.string().describe('Question used to look up the answer in saved memories.'),
  }),
  outputSchema: z.object({
    answer: z.string().describe('Remembered answer'),
  }),
  execute: async ({ context }) => {
    console.log(`Searching memory "${context.question}"`);
    const memory = await mem0.searchMemory(context.question);
    console.log(`\nFound memory "${memory}"\n`);

    return {
      answer: memory,
    };
  },
});

export const mem0MemorizeTool = createTool({
  id: 'Mem0-memorize',
  description: 'Save information to mem0 so you can remember it later using the Mem0-remember tool.',
  inputSchema: z.object({
    statement: z.string().describe('A statement to save into memory'),
  }),
  execute: async ({ context }) => {
    console.log(`\nCreating memory "${context.statement}"\n`);
    // to reduce latency memories can be saved async without blocking tool execution
    void mem0.createMemory(context.statement).then(() => {
      console.log(`\nMemory "${context.statement}" saved.\n`);
    });
    return { success: true };
  },
});

```
