# @mastra/voice-gladia

## 0.10.1

### Patch Changes

- f4007f8: Add gladia-api speech to text provider
- Updated dependencies [63f6b7d]
- Updated dependencies [12a95fc]
- Updated dependencies [4b0f8a6]
- Updated dependencies [51264a5]
- Updated dependencies [8e6f677]
- Updated dependencies [d70c420]
- Updated dependencies [ee9af57]
- Updated dependencies [36f1c36]
- Updated dependencies [2a16996]
- Updated dependencies [10d352e]
- Updated dependencies [9589624]
- Updated dependencies [53d3c37]
- Updated dependencies [751c894]
- Updated dependencies [577ce3a]
- Updated dependencies [9260b3a]
  - @mastra/core@0.10.6

## 0.10.1-alpha.0

### Patch Changes

- f4007f8: Add gladia-api speech to text provider
- Updated dependencies [4b0f8a6]
  - @mastra/core@0.10.6-alpha.2
