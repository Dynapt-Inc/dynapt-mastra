/**
 * Scans example directories and creates flattened code example files
 */
export declare function prepareCodeExamples(): Promise<void>;
//# sourceMappingURL=code-examples.d.ts.map