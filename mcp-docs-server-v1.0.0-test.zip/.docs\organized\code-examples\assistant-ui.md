### package.json
```json
{
  "name": "examples-assistant-ui",
  "private": true,
  "scripts": {
    "dev": "next dev --turbo",
    "build": "next build",
    "start": "next start",
    "lint": "next lint"
  },
  "dependencies": {
    "@ai-sdk/openai": "latest",
    "@assistant-ui/react": "0.7.85",
    "@assistant-ui/react-markdown": "^0.7.21",
    "@assistant-ui/react-ui": "^0.1.8",
    "@mastra/client-js": "latest",
    "next": "^15.3.1",
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "tailwindcss-animate": "^1.0.7",
    "zod": "^3.25.56"
  },
  "pnpm": {
    "overrides": {
      "@mastra/client-js": "link:../../client-sdks/client-js"
    }
  },
  "devDependencies": {
    "@types/node": "^20.17.57",
    "@types/react": "^19.0.10",
    "@types/react-dom": "^19.0.4",
    "eslint": "^8.57.1",
    "eslint-config-next": "15.3.3",
    "postcss": "^8.5.3",
    "tailwindcss": "^3.4.17",
    "typescript": "^5.8.2"
  },
  "version": "0.0.0",
  "packageManager": "pnpm@10.10.0+sha512.d615db246fe70f25dcfea6d8d73dee782ce23e2245e3c4f6f888249fb568149318637dca73c2c5c8ef2a4ca0d5657fb9567188bfab47f566d1ee6ce987815c39"
}

```
