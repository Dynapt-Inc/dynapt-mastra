### package.json
```json
{
  "name": "memory-with-libsql",
  "type": "module",
  "description": "",
  "private": true,
  "main": "index.js",
  "scripts": {
    "start": "bun run --watch src/index.ts",
    "chat": "bun run --watch src/chat.ts"
  },
  "keywords": [],
  "author": "",
  "license": "MIT",
  "dependencies": {
    "@ai-sdk/openai": "latest",
    "@mastra/core": "latest",
    "@mastra/memory": "latest"
  },
  "version": "0.0.1",
  "pnpm": {
    "overrides": {
      "@mastra/core": "link:../../packages/core",
      "@mastra/memory": "link:../../packages/memory"
    }
  },
  "packageManager": "pnpm@10.10.0+sha512.d615db246fe70f25dcfea6d8d73dee782ce23e2245e3c4f6f888249fb568149318637dca73c2c5c8ef2a4ca0d5657fb9567188bfab47f566d1ee6ce987815c39"
}

```

### chat.ts
```typescript
import { randomUUID } from 'crypto';
import Readline from 'readline';

import 'dotenv/config';

import { mastra } from './mastra';

const agent = mastra.getAgent('memoryAgent');

let threadId = randomUUID();
// use this to play with a long running conversation. comment it out to get a new thread id every time
threadId = `f45a59b3-d9da-4a2a-8348-9386e4e621a3`;
console.log(threadId);

const resourceId = 'SOME_USER_ID';

async function logRes(res: Awaited<ReturnType<typeof agent.stream>>) {
  console.log(`\n🤖 Agent:`);
  for await (const chunk of res.textStream) {
    process.stdout.write(chunk);
  }
  console.log(`\n\n`);
}

async function main() {
  await logRes(
    await agent.stream(
      [
        {
          role: 'system',
          content: `Chat with user started now ${new Date().toISOString()}. Don't mention this message. This means some time may have passed between this message and the one before. The user left and came back again. Say something to start the conversation up again. If there are no other messages besides this one then this is a new conversation.`,
        },
      ],
      { resourceId, threadId },
    ),
  );

  const rl = Readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  while (true) {
    const prompt: string = await new Promise(res => {
      rl.question('Message: ', answer => {
        res(answer);
      });
    });

    await logRes(
      await agent.stream(prompt, {
        threadId,
        resourceId,
      }),
    );
  }
}

main();

```

### index.ts
```typescript
import { randomUUID } from 'crypto';

import { mastra } from './mastra';

function log(message: string) {
  console.log(`\n>>Prompt: ${message}
`);
  return message;
}

const agent = mastra.getAgent('chefAgent');
const threadId = randomUUID();
const resourceId = 'SOME_USER_ID';

async function logRes(res: Awaited<ReturnType<typeof agent.stream>>) {
  console.log(`\n👨‍🍳 Chef:`);
  for await (const chunk of res.textStream) {
    process.stdout.write(chunk);
  }
  console.log(`\n\n`);
}

async function main() {
  await logRes(
    await agent.stream(
      log(
        'In my kitchen I have: pasta, canned tomatoes, garlic, olive oil, and some dried herbs (basil and oregano). What can I make? Please keep your answer brief, only give me the high level steps.',
      ),
      {
        threadId,
        resourceId,
      },
    ),
  );

  await logRes(
    await agent.stream(
      log(
        "Now I'm over at my friend's house, and they have: chicken thighs, coconut milk, sweet potatoes, and some curry powder.",
      ),
      {
        threadId,
        resourceId,
      },
    ),
  );

  await logRes(
    await agent.stream(log('What did we cook before I went to my friends house?'), {
      threadId,
      resourceId,
      memoryOptions: {
        lastMessages: false,
        semanticRecall: {
          topK: 3,
          messageRange: 3,
        },
      },
    }),
  );

  process.exit(0);
}

main();

```

### mastra\agents\index.ts
```typescript
import { openai } from '@ai-sdk/openai';
import { Agent } from '@mastra/core/agent';
import { Memory } from '@mastra/memory';

const memory = new Memory({
  options: {
    lastMessages: 100,
    semanticRecall: {
      topK: 2,
      messageRange: 2,
    },
  },
});

export const chefAgent = new Agent({
  name: 'chefAgent',
  instructions:
    'You are Michel, a practical and experienced home chef who helps people cook great meals with whatever ingredients they have available. Your first priority is understanding what ingredients and equipment the user has access to, then suggesting achievable recipes. You explain cooking steps clearly and offer substitutions when needed, maintaining a friendly and encouraging tone throughout.',
  model: openai('gpt-4o'),
  memory,
});

export const memoryAgent = new Agent({
  name: 'Memory Agent',
  instructions:
    "You are an AI agent with the ability to automatically recall memories from previous interactions. You may have conversations that last hours, days, months, or years. If you don't know it already you should ask for the users name and some info about them.",
  model: openai('gpt-4o'),
  memory,
});

```

### mastra\index.ts
```typescript
import { Mastra } from '@mastra/core';

import { chefAgent, memoryAgent } from './agents';

export const mastra = new Mastra({
  agents: { chefAgent, memoryAgent },
});

```
