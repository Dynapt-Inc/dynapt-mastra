import { MCPClient } from '@mastra/mcp';
export declare const server: import("@hono/node-server/.").ServerType;
export declare const mcp: MCPClient;
export declare function callTool(tool: any, args: any): Promise<string>;
//# sourceMappingURL=test-setup.d.ts.map