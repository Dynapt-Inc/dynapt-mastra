export declare function fromRepoRoot(relative: string): string;
export declare function fromPackageRoot(relative: string): string;
export declare const log: {
    (...data: any[]): void;
    (message?: any, ...optionalParams: any[]): void;
};
export declare function getMatchingPaths(path: string, queryKeywords: string[], baseDir: string): Promise<string>;
//# sourceMappingURL=utils.d.ts.map