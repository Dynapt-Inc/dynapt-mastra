export declare function copyRaw(): Promise<void>;
//# sourceMappingURL=copy-raw.d.ts.map