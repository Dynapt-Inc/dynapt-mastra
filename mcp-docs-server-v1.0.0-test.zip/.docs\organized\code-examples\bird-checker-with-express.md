### package.json
```json
{
  "name": "examples-bird-checker-with-express",
  "description": "",
  "type": "module",
  "main": "index.js",
  "version": "0.0.1",
  "scripts": {
    "start": "tsx src/index.ts"
  },
  "private": true,
  "keywords": [],
  "author": "",
  "license": "MIT",
  "devDependencies": {
    "@types/express": "^4.0.0",
    "@types/node": "^20.17.57",
    "concurrently": "^9.1.2",
    "dotenv": "^16.5.0",
    "express": "^4.21.2",
    "nodemon": "^3.1.9",
    "ts-node": "^10.9.2",
    "tsx": "^4.19.3",
    "typescript": "^5.8.2"
  },
  "dependencies": {
    "@ai-sdk/anthropic": "latest",
    "@mastra/core": "latest",
    "ai": "latest",
    "zod": "^3.25.56"
  },
  "pnpm": {
    "overrides": {
      "@mastra/core": "link:../../packages/core"
    }
  },
  "packageManager": "pnpm@10.10.0+sha512.d615db246fe70f25dcfea6d8d73dee782ce23e2245e3c4f6f888249fb568149318637dca73c2c5c8ef2a4ca0d5657fb9567188bfab47f566d1ee6ce987815c39"
}

```

### index.ts
```typescript
import { config } from 'dotenv';
import express, { Request, Response } from 'express';
import { z } from 'zod';

import { getRandomImage, ImageQuery } from './lib/utils';
import { mastra } from './mastra/index';

config();

const app = express();

app.use(express.json());

const port = process.env.PORT || 3001;

app.get('/', (req: Request, res: Response) => {
  res.send('Hello, TypeScript Express!');
});

app.get('/api/get-unsplash-image', async (req: Request, res: Response) => {
  try {
    const imageQuery = (req?.query?.query || 'wildlife') as ImageQuery;

    const image = await getRandomImage({ query: imageQuery });

    if (!image.ok) {
      res.status(400).send({ msg: image.error });
      return;
    }

    res.send(image.data);
  } catch (err) {
    console.log('get unsplash image err===', err);
    res.status(400).send({ msg: 'Could not fetch image' });
  }
});

app.post('/api/image-metadata', async (req: Request, res: Response) => {
  try {
    const imageUrl = req.body?.imageUrl;

    if (!imageUrl) {
      res.status(400).send({ msg: 'Image url is required' });
      return;
    }

    const birdCheckerAgent = mastra.getAgent('birdCheckerAgent');

    if (!birdCheckerAgent) {
      res.sendStatus(404);
      return;
    }

    const response = await birdCheckerAgent.generate(
      [
        {
          role: 'user',
          content: [
            {
              type: 'image',
              image: imageUrl,
            },
            {
              type: 'text',
              text: "view this image and let me know if it's a bird or not, and the scientific name of the bird without any explanation. Also summarize the location for this picture in one or two short sentences understandable by a high school student",
            },
          ],
        },
      ],
      {
        output: z.object({
          bird: z.boolean(),
          species: z.string(),
          location: z.string(),
        }),
      },
    );

    const { object } = response;

    console.log('response==', JSON.stringify(object, null, 2));

    res.send(object);
  } catch (err) {
    console.log('get image metadata err===', err);
    res.status(400).send({ msg: 'Could not fetch image metadata' });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

```

### lib\utils.ts
```typescript
export type ImageQuery = 'wildlife' | 'feathers' | 'flying' | 'birds';

export const getRandomImage = async ({ query }: { query: ImageQuery }) => {
  const page = Math.floor(Math.random() * 20);
  const order_by = Math.random() < 0.5 ? 'relevant' : 'latest';
  try {
    const res = await fetch(`https://api.unsplash.com/search/photos?query=${query}&page=${page}&order_by=${order_by}`, {
      method: 'GET',
      headers: {
        Authorization: `Client-ID ${process.env.UNSPLASH_ACCESS_KEY}`,
        'Accept-Version': 'v1',
      },
      //@ts-ignore
      cache: 'no-store',
    });

    if (!res.ok) {
      console.log('res-----', res);
      return {
        ok: false,
        error: 'Failed to fetch image',
      };
    }

    const data = (await res.json()) as { results: any[] };
    const randomNo = Math.floor(Math.random() * data.results.length);

    const { urls, user } = data.results[randomNo];

    const resp = {
      imageUrl: urls?.raw,
      photographerName: user?.first_name,
      photographerProfile: user?.links?.html,
    };

    return {
      ok: true,
      data: resp,
    };
  } catch (err) {
    console.log('Error in get_random_image api executor===', err);
    return {
      ok: false,
      error: 'Error fetching image',
    };
  }
};

```

### mastra\agents\agent.ts
```typescript
import { anthropic } from '@ai-sdk/anthropic';
import { Agent } from '@mastra/core/agent';

export const birdCheckerAgent = new Agent({
  name: 'Bird checker',
  instructions:
    'You can view an image and figure out if it is a bird or not. You can also figure out the species of the bird and where the picture was taken.',
  model: anthropic('claude-3-haiku-20240307'),
});

```

### mastra\index.ts
```typescript
import { PinoLogger } from '@mastra/loggers';
import { Mastra } from '@mastra/core';

import { birdCheckerAgent } from './agents/agent';

export const mastra = new Mastra({
  agents: { birdCheckerAgent },
  logger: new PinoLogger({
    name: 'CONSOLE',
    level: 'info',
  }),
});

```

### mastra\tools\index.ts
```typescript
import { createTool } from '@mastra/core/tools';
import { z } from 'zod';

import { getRandomImage } from '../../lib/utils';

export const getRandomImageTool = createTool({
  id: 'Get a random image from unsplash',
  description: 'Gets a random image from unsplash based on the selected option',
  inputSchema: z.object({
    query: z.enum(['wildlife', 'feathers', 'flying', 'birds']),
  }),
  execute: async ({ context }) => {
    return getRandomImage(context);
  },
});

```
