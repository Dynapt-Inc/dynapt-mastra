export declare function prepare(): Promise<void>;
//# sourceMappingURL=prepare.d.ts.map