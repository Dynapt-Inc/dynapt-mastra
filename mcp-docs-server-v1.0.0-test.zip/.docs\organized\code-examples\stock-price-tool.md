### package.json
```json
{
  "name": "examples-stock-price-tool",
  "type": "module",
  "private": true,
  "main": "index.js",
  "scripts": {
    "dev": "mastra dev",
    "test": "cross-env NODE_OPTIONS='--experimental-vm-modules --max-old-space-size=8192' jest"
  },
  "keywords": [],
  "author": "",
  "license": "MIT",
  "description": "",
  "dependencies": {
    "@ai-sdk/openai": "latest",
    "@mastra/core": "latest",
    "zod": "^3.25.56"
  },
  "devDependencies": {
    "@jest/globals": "^29.7.0",
    "jest": "^29.7.0",
    "mastra": "latest",
    "ts-jest": "^29.2.6"
  },
  "pnpm": {
    "overrides": {
      "@mastra/core": "link:../../packages/core",
      "mastra": "link:../../packages/cli"
    }
  },
  "version": "0.0.1",
  "packageManager": "pnpm@10.10.0+sha512.d615db246fe70f25dcfea6d8d73dee782ce23e2245e3c4f6f888249fb568149318637dca73c2c5c8ef2a4ca0d5657fb9567188bfab47f566d1ee6ce987815c39"
}

```

### index.ts
```typescript
import { mastra } from './mastra';

async function main() {
  const stockAgent = mastra.getAgent('stockAgent');
  const response = await stockAgent.generate('What is the current stock price of Apple (AAPL)?');

  const toolCall: any = response.toolResults.find((result: any) => result.toolName === 'stockPrices');

  const currentPrice = toolCall?.result?.currentPrice;

  console.log(`The current price of Apple (AAPL) is $${currentPrice}`);
}

main();

```

### mastra\agents\index.ts
```typescript
import { openai } from '@ai-sdk/openai';
import { Agent } from '@mastra/core/agent';

import { stockPrices } from '../tools/stock-price';

export const stockAgent = new Agent({
  name: 'Stock Agent',
  instructions:
    'You are a helpful assistant that provides current stock prices. When asked about a stock, use the stock price tool to fetch the stock price.',
  model: openai('gpt-4o'),
  tools: {
    stockPrices,
  },
});

```

### mastra\index.ts
```typescript
import { Mastra } from '@mastra/core';

import { stockAgent } from './agents';

export const mastra = new Mastra({
  agents: { stockAgent },
});

```

### mastra\tools\stock-price.ts
```typescript
import { createTool } from '@mastra/core/tools';
import { z } from 'zod';

export const getStockPrice = async (symbol: string) => {
  const data = await fetch(`https://mastra-stock-data.vercel.app/api/stock-data?symbol=${symbol}`).then(r => r.json());
  return data.prices['4. close'];
};

export const stockPrices = createTool({
  id: 'Get Stock Price',
  inputSchema: z.object({
    symbol: z.string(),
  }),
  description: `Fetches the last day's closing stock price for a given symbol`,
  execute: async ({ context }) => {
    console.log('Using tool to fetch stock price for', context.symbol);
    return {
      symbol: context.symbol,
      currentPrice: await getStockPrice(context.symbol),
    };
  },
});

```

### mastra\tools\tools.test.ts
```typescript
import { describe, it, expect } from 'vitest';

import { getStockPrice } from './stock-price';

describe('Test Tools', () => {
  it('should run the stockPrices', async () => {
    const result = await getStockPrice('AAPL');

    console.log(result);
    expect(result).toBeDefined();
  });
});

```
