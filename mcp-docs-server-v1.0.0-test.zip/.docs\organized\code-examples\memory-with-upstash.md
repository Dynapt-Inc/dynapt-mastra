### package.json
```json
{
  "name": "memory-with-upstash",
  "type": "module",
  "version": "1.0.1",
  "description": "",
  "private": true,
  "main": "index.js",
  "scripts": {
    "prestart": "docker compose up -d",
    "start": "npx bun src/index.ts",
    "poststart": "docker compose down"
  },
  "keywords": [],
  "author": "",
  "license": "MIT",
  "dependencies": {
    "@ai-sdk/openai": "latest",
    "@mastra/core": "latest",
    "@mastra/memory": "latest",
    "@mastra/pg": "latest",
    "@mastra/upstash": "latest"
  },
  "pnpm": {
    "overrides": {
      "@mastra/core": "link:../../packages/core",
      "@mastra/memory": "link:../../packages/memory",
      "@mastra/pg": "link:../../stores/pg",
      "@mastra/upstash": "link:../../stores/upstash"
    }
  },
  "devDependencies": {
    "dotenv": "^16.5.0",
    "tsx": "^4.19.3"
  },
  "packageManager": "pnpm@10.10.0+sha512.d615db246fe70f25dcfea6d8d73dee782ce23e2245e3c4f6f888249fb568149318637dca73c2c5c8ef2a4ca0d5657fb9567188bfab47f566d1ee6ce987815c39"
}

```

### bubble.ts
```typescript
type BubbleStyle = 'simple' | 'rounded';

interface BubbleOptions {
  style?: BubbleStyle;
  maxWidth?: number;
}

interface BubbleCharacters {
  topLeft: string;
  topRight: string;
  bottomLeft: string;
  bottomRight: string;
  horizontal: string;
  vertical: string;
}

class MessageBubble {
  private readonly defaultMaxWidth = 80;
  private readonly defaultStyle: BubbleStyle = 'simple';

  private readonly styleCharacters: Record<BubbleStyle, BubbleCharacters> = {
    rounded: {
      topLeft: '╭',
      topRight: '╮',
      bottomLeft: '╰',
      bottomRight: '╯',
      horizontal: '─',
      vertical: '│',
    },
    simple: {
      topLeft: '+',
      topRight: '+',
      bottomLeft: '+',
      bottomRight: '+',
      horizontal: '-',
      vertical: '|',
    },
  };

  private wrapText(text: string, maxWidth: number): string[] {
    const lines: string[] = [];
    const rawLines = text.split('\n');

    rawLines.forEach((line: string) => {
      const isListItem = line.trim().match(/^[-*•]\s/);
      const indent = isListItem ? 2 : 0;
      const availableWidth = maxWidth - indent;

      if (line.trim() === '') {
        lines.push('');
        return;
      }

      let currentLine = '';
      const words = line.trim().split(' ');

      words.forEach((word: string) => {
        if (currentLine === '' && isListItem) {
          currentLine = '  ' + word;
        } else if (currentLine === '') {
          currentLine = word;
        } else if ((currentLine + ' ' + word).length <= maxWidth) {
          currentLine += ' ' + word;
        } else {
          lines.push(currentLine);
          currentLine = isListItem ? '  ' + word : word;
        }
      });

      if (currentLine) {
        lines.push(currentLine);
      }
    });

    return lines;
  }

  private validateOptions(options: BubbleOptions): void {
    if (options.maxWidth && options.maxWidth < 20) {
      throw new Error('maxWidth must be at least 20 characters');
    }
    if (options.style && !this.styleCharacters[options.style]) {
      throw new Error('Invalid style. Must be either "simple" or "rounded"');
    }
  }

  public print(message: string, options: BubbleOptions = {}): void {
    this.validateOptions(options);

    const maxWidth = options.maxWidth || this.defaultMaxWidth;
    const style = options.style || this.defaultStyle;
    const chars = this.styleCharacters[style];

    // Process and wrap the text
    const wrappedLines = this.wrapText(message, maxWidth - 4);
    const contentWidth = Math.min(maxWidth - 4, Math.max(...wrappedLines.map(line => line.length)));

    // Create borders
    const topBorder = chars.topLeft + chars.horizontal.repeat(contentWidth + 2) + chars.topRight;
    const bottomBorder = chars.bottomLeft + chars.horizontal.repeat(contentWidth + 2) + chars.bottomRight;

    // Print the bubble
    console.log(topBorder);
    wrappedLines.forEach(line => {
      console.log(`${chars.vertical} ${line.padEnd(contentWidth)} ${chars.vertical}`);
    });
    console.log(bottomBorder);
    console.log('  ╰╯');
  }
}

// Example usage:
export const bubble = new MessageBubble();

```

### index.ts
```typescript
import { randomUUID } from 'crypto';

import { mastra } from './mastra';

function log(message: string) {
  console.log(`\n>>Prompt: ${message}
`);
  return message;
}

const agent = mastra.getAgent('chefAgent');
const threadId = randomUUID();
const resourceId = 'SOME_USER_ID';

async function logRes(res: Awaited<ReturnType<typeof agent.stream>>) {
  console.log(`\n👨‍🍳 Chef:`);
  for await (const chunk of res.textStream) {
    process.stdout.write(chunk);
  }
  console.log(`\n\n`);
}

async function main() {
  await logRes(
    await agent.stream(
      log(
        'In my kitchen I have: pasta, canned tomatoes, garlic, olive oil, and some dried herbs (basil and oregano). What can I make? Please keep your answer brief, only give me the high level steps.',
      ),
      {
        threadId,
        resourceId,
      },
    ),
  );

  await logRes(
    await agent.stream(
      log(
        "Now I'm over at my friend's house, and they have: chicken thighs, coconut milk, sweet potatoes, and some curry powder.",
      ),
      {
        threadId,
        resourceId,
      },
    ),
  );

  await logRes(
    await agent.stream(log('What did we cook before I went to my friends house?'), {
      threadId,
      resourceId,
      memoryOptions: {
        lastMessages: 3,
      },
    }),
  );

  process.exit(0);
}

main();

```

### mastra\agents\index.ts
```typescript
import { openai } from '@ai-sdk/openai';
import { Agent } from '@mastra/core';
import { Memory } from '@mastra/memory';
import { PgVector } from '@mastra/pg';
import { UpstashStore } from '@mastra/upstash';

const memory = new Memory({
  storage: new UpstashStore({
    url: 'http://localhost:8089',
    token: 'test_token',
  }),
  vector: new PgVector({ connectionString: `postgresql://postgres:postgres@localhost:5433` }),
  options: {
    lastMessages: 1,
    semanticRecall: {
      topK: 3,
      messageRange: 2,
    },
  },
});

export const chefAgent = new Agent({
  name: 'chefAgent',
  memory,
  instructions:
    'You are Michel, a practical and experienced home chef who helps people cook great meals with whatever ingredients they have available. Your first priority is understanding what ingredients and equipment the user has access to, then suggesting achievable recipes. You explain cooking steps clearly and offer substitutions when needed, maintaining a friendly and encouraging tone throughout.',
  model: openai('gpt-4o'),
});

export const memoryAgent = new Agent({
  name: 'Memory Agent',
  memory,
  instructions:
    "You are an AI agent with the ability to automatically recall memories from previous interactions. You may have conversations that last hours, days, months, or years. If you don't know it already you should ask for the users name and some info about them.",
  model: openai('gpt-4o'),
});

```

### mastra\index.ts
```typescript
import { Mastra } from '@mastra/core';

import { chefAgent, memoryAgent } from './agents';

export const mastra = new Mastra({
  agents: { chefAgent, memoryAgent },
});

```
