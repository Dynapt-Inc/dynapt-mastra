# @mastra/fastembed

## 0.0.3

### Patch Changes

- 48b8c2c: dependencies updates:
  - Updated dependency [`ai@^3.4.33` ↗︎](https://www.npmjs.com/package/ai/v/3.4.33) (from `^3.0.0`, in `dependencies`)

## 0.0.3-alpha.0

### Patch Changes

- 48b8c2c: dependencies updates:
  - Updated dependency [`ai@^3.4.33` ↗︎](https://www.npmjs.com/package/ai/v/3.4.33) (from `^3.0.0`, in `dependencies`)

## 0.0.2

### Patch Changes

- 3a5f1e1: Created a new @mastra/fastembed package based on the default embedder in @mastra/core as the default embedder will be removed in a breaking change (May 20th)
  Added a warning to use the new @mastra/fastembed package instead of the default embedder

## 0.0.2-alpha.0

### Patch Changes

- 3a5f1e1: Created a new @mastra/fastembed package based on the default embedder in @mastra/core as the default embedder will be removed in a breaking change (May 20th)
  Added a warning to use the new @mastra/fastembed package instead of the default embedder
