export { fastembed } from './index.js';
