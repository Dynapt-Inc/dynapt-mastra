export declare const fastembed: import("ai").EmbeddingModel<string> & {
    small: import("ai").EmbeddingModel<string>;
    base: import("ai").EmbeddingModel<string>;
};
//# sourceMappingURL=index.d.ts.map