export { PinoLogger } from './pino';
export type { LogLevel } from './pino';
//# sourceMappingURL=index.d.ts.map