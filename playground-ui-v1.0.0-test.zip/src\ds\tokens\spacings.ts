export const Spacings = {
  sm: '2px',
  md: '4px',
  lg: '8px',
};
