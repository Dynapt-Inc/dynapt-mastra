export const BorderWidth = {
  sm: '0.5px',
};

export const BorderRadius = {
  none: '0px',
  sm: '2px',
  md: '4px',
  lg: '6px',
};
