import type { LanguageModelV1 } from 'ai';
import type { ZodTypeAny } from 'zod';
import type { Targets } from 'zod-to-json-schema';
import { SchemaCompatLayer } from '../schema-compatibility';
export declare class DeepSeekSchemaCompatLayer extends SchemaCompatLayer {
    constructor(model: LanguageModelV1);
    getSchemaTarget(): Targets | undefined;
    shouldApply(): boolean;
    processZodType(value: ZodTypeAny): ZodTypeAny;
}
//# sourceMappingURL=deepseek.d.ts.map